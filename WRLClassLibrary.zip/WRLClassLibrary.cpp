#include "pch.h"

#include "$safeprojectname$_h.h"
#include <wrl.h>

using namespace Microsoft::WRL;
using namespace Windows::Foundation;

namespace ABI
{
	namespace $safeprojectname$
	{
		class WinRTClass: public RuntimeClass<IWinRTClass>
		{
			InspectableClass(L"$safeprojectname$.WinRTClass", BaseTrust)

			public:
			WinRTClass()
			{
			}

			// http://msdn.microsoft.com/en-us/library/jj155856.aspx
			// Walkthrough: Creating a Basic Windows Runtime Component Using WRL
			HRESULT __stdcall Add(_In_ int a, _In_ int b, _Out_ int* value)
			{
				if (value == nullptr)
				{
					return E_POINTER;
				}
				*value = a + b;
				return S_OK;
			}

		};

		ActivatableClass(WinRTClass);
	}
}