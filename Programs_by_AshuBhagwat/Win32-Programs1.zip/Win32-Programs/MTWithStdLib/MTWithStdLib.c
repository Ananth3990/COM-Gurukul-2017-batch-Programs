#include<windows.h>
#include<stdio.h>		// for sprintf()
#include<process.h>	// for _beginthread()

LRESULT CALLBACK WndProc(HWND, UINT, WPARAM, LPARAM);

// ThreadProc() functions
void __cdecl MyThreadProcOne(void *);
void __cdecl MyThreadProcTwo(void *);

int WINAPI WinMain(HINSTANCE hInstance,HINSTANCE hPrevInstance,
				   LPSTR lpCmdLine,int nCmdShow)
{
	WNDCLASSEX wndclass;
	HWND hwnd;
	MSG msg;
	char AppName[] = "MULTITHREADING";

	wndclass.cbSize = sizeof(wndclass);
	wndclass.style = CS_HREDRAW | CS_VREDRAW;
	wndclass.cbClsExtra = 0;
	wndclass.cbWndExtra = 0;
	wndclass.lpfnWndProc = WndProc;
	wndclass.hIcon = LoadIcon(NULL, IDI_APPLICATION);
	wndclass.hCursor = LoadCursor(NULL, IDC_ARROW);
	wndclass.hIconSm = LoadIcon(NULL, IDI_APPLICATION);
	wndclass.hbrBackground = (HBRUSH) GetStockObject(WHITE_BRUSH);
	wndclass.hInstance = hInstance;
	wndclass.lpszClassName = AppName;
	wndclass.lpszMenuName = NULL;

	RegisterClassEx(&wndclass);

	hwnd=CreateWindow(AppName,
		            "Example Of Multithreading",
				WS_OVERLAPPEDWINDOW,
				CW_USEDEFAULT,
				CW_USEDEFAULT,
				CW_USEDEFAULT,
				CW_USEDEFAULT,
                        NULL,
                        NULL,
				hInstance,
				NULL);

	ShowWindow(hwnd,nCmdShow);
	UpdateWindow(hwnd);

	while (GetMessage(&msg, NULL, 0, 0)) {
		TranslateMessage(&msg);
		DispatchMessage(&msg);
	}

	//Previously for Visual Studio6
//	return (msg.wParam);
	return ((int)msg.wParam);
}

// Window Procedure
LRESULT CALLBACK WndProc(HWND hwnd, UINT iMsg, WPARAM wParam, LPARAM lParam)
{
	unsigned long ulThread1,ulThread2;

	switch (iMsg) {
		case WM_CREATE:
			//Previously for Visual Studio6
			//ulThread1=_beginthread(MyThreadProcOne,0,(void *)hwnd);
			ulThread1=(unsigned long )_beginthread(MyThreadProcOne,0,(void *)hwnd);
			
			//Previously for Visual Studio6
			//ulThread2=_beginthread(MyThreadProcTwo,0,(void *)hwnd);
			ulThread2=(unsigned long )_beginthread(MyThreadProcTwo,0,(void *)hwnd);
			break;

		case WM_DESTROY:
			PostQuitMessage(0);
			break;
	}
	return (DefWindowProc(hwnd, iMsg, wParam, lParam));
}

void __cdecl MyThreadProcOne(void *param)
{
	HDC hdc;
	int i;
	char str[255];

	hdc = GetDC((HWND)param);
	for(i = 0; i <=32767; i++) {
		//Previously for Visual Studio6
		//sprintf(str, "Thread 1 -> Increasing Order Output = %d", i);
		sprintf_s(str,255,"Thread 1 -> Increasing Order Output = %d", i);
		//Previously for Visual Studio6
		//TextOut(hdc, 5, 5, str, strlen(str));
		TextOut(hdc, 5, 5, str, (int)strlen(str));
	}
	ReleaseDC((HWND)param, hdc);
}

void __cdecl MyThreadProcTwo(void *param)
{
	HDC hdc;
	int i;
	char str[255];

	hdc = GetDC((HWND)param);
	for(i = 32767; i >= 0; i--) {
		//Previously for Visual Studio6
		//sprintf(str, "Thread 2 -> Decreasing Order Output = %d", i);
		sprintf_s(str,255,"Thread 2 -> Increasing Order Output = %d", i);
		//Previously for Visual Studio6
		//TextOut(hdc, 5, 25, str, strlen(str));
		TextOut(hdc, 5, 25, str, (int)strlen(str));
	}
	ReleaseDC((HWND)param,hdc);
}
