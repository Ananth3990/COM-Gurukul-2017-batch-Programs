__declspec(dllexport) int SumOfTwoIntegers(int,int);
__declspec(dllexport) int SubtractionOfTwoIntegers(int,int);