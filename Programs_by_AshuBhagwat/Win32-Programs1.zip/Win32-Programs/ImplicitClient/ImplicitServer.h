// exported function prototypes
__declspec(dllexport) int SumOfTwoIntegers(int,int);
__declspec(dllexport) int SubtractionOfTwoIntegers(int,int);
